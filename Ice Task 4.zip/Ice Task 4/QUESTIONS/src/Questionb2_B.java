import java.util.Arrays;
import java.util.Scanner;

public class LessonWithRentalDemo {

    public static void main(String[] args) {
        final int NUM_RENTALS = 4;
        LessonWithRental[] rentals = new LessonWithRental[NUM_RENTALS];
        Scanner input = new Scanner(System.in);

        for (int i = 0; i < NUM_RENTALS; i++) {
            System.out.println("Enter contract number:");
            String contractNumber = input.nextLine();
            System.out.println("Enter minutes for rental:");
            int minutes = input.nextInt();
            System.out.println("Enter equipment type (0: Personal Watercraft, 1: Pontoon Boat, 2: Rowboat, 3: Canoe, 4: Kayak, 5: Beach Chair, 6: Umbrella, 7: Surfboard):");
            int equipmentType = input.nextInt();
            input.nextLine();

            rentals[i] = new LessonWithRental(contractNumber, minutes, equipmentType);
        }

        boolean continueSorting = true;
        while (continueSorting) {
            System.out.println("\nHow would you like to sort the rentals?");
            System.out.println("1. By Contract Number");
            System.out.println("2. By Equipment Type");
            System.out.println("3. By Price (Minutes)");
            System.out.println("4. Exit");
            int choice = input.nextInt();

            switch (choice) {
                case 1:
                    Arrays.sort(rentals, (r1, r2) -> r1.getContractNumber().compareTo(r2.getContractNumber()));
                    break;
                case 2:
                    Arrays.sort(rentals, (r1, r2) -> r1.getEquipmentType().compareTo(r2.getEquipmentType()));
                    break;
                case 3:
                    Arrays.sort(rentals, (r1, r2) -> Integer.compare(r1.getHours(), r2.getHours()));
                    break;
                case 4:
                    continueSorting = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    continue;
            }

            if (choice != 4) {
                for (LessonWithRental rental : rentals) {
                    System.out.println("Contract " + rental.getContractNumber() + ": " + rental.getInstructor());
                }
            }
        }

        input.close();
    }
}
