package Question1;

import java.util.ArrayList;
import java.util.Scanner;

class RaceHorse extends Horse {
    private int races;
     public void setRace(String race) {
         this.races = Integer.parseInt(race);}

    public int getRaces(){
         return races;
    }

}
