package Question1;

public class Horse {
    private String name;
    private String color;
    private int birthYear;
//set method
    public void setName(String name) {
        this.name = name;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public void setBirthYear(int birthYear) {
        this.birthYear = birthYear;
    }

    //get method
    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }

    public int getBirthYear() {
        return birthYear;
    }
}