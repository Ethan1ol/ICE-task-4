import java.util.Scanner;

public class DemoBaseballGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select game type: 1. Baseball 2. High School Baseball 3. Little League Baseball");
        int gameType = scanner.nextInt();
        scanner.nextLine();


        System.out.println("Enter Team 1 name: ");
        String team1 = scanner.nextLine();
        System.out.println("Enter Team 2 name: ");
        String team2 = scanner.nextLine();

        BaseballGame game;


        if (gameType == 1) {
            game = new BaseballGame(team1, team2);
        } else if (gameType == 2) {
            game = new HighSchoolBaseballGame(team1, team2);
        } else if (gameType == 3) {
            game = new LittleLeagueBaseballGame(team1, team2);
        } else {
            System.out.println("Invalid game type.");
            return;
        }

        int totalInnings = gameType == 1 ? 9 : (gameType == 2 ? 7 : 6);

        for (int i = 1; i <= totalInnings; i++) {
            System.out.println("Inning " + i);
            System.out.println("Enter score for " + team1 + ": ");
            int score1 = scanner.nextInt();
            game.setScore(team1, i, score1);

            System.out.println("Enter score for " + team2 + ": ");
            int score2 = scanner.nextInt();
            game.setScore(team2, i, score2);

            System.out.println("Running score:");
            System.out.println(team1 + ": " + game.getTotalScore(team1));
            System.out.println(team2 + ": " + game.getTotalScore(team2));
        }

        int finalScoreTeam1 = game.getTotalScore(team1);
        int finalScoreTeam2 = game.getTotalScore(team2);

        System.out.println("Final Score:");
        System.out.println(team1 + ": " + finalScoreTeam1);
        System.out.println(team2 + ": " + finalScoreTeam2);

        if (finalScoreTeam1 > finalScoreTeam2) {
            System.out.println(team1 + " wins!");
        } else if (finalScoreTeam2 > finalScoreTeam1) {
            System.out.println(team2 + " wins!");
        } else {
            System.out.println("It's a tie!");
        }
    }
}