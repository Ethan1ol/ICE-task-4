public class LittleLeagueBaseballGame extends BaseballGame {
    private final int INNINGS = 6;

    public LittleLeagueBaseballGame(String team1, String team2) {
        super(team1, team2);
    }


    @Override
    public void setScore(String team, int inning, int score) {
        if (inning < 1 || inning > INNINGS) {
            System.out.println("Invalid inning. Little league games have 6 innings.");
            return;
        }
        super.setScore(team, inning, score);
    }
}
