
public class Limerick extends Poem {


    public Limerick(String title) {
        super(title, 5);
    }

    @Override
    public String toString() {
        return "Limerick: " + getTitle() + ", Number of lines: " + getLines();
    }

    public class Haiku extends Poem {

        public Haiku(String title) {
            super(title, 3);
        }

        @Override
        public String toString() {
            return "Haiku: " + getTitle() + ", Number of lines: " + getLines();
        }
    }

}
