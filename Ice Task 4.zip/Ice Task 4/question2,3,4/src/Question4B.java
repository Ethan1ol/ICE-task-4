
public class Poem {
    private String title;
    private int lines;


    public Poem(String title, int lines) {
        this.title = title;
        this.lines = lines;
    }


    public String getTitle() {
        return title;
    }

    public int getLines() {
        return lines;
    }


    @Override
    public String toString() {
        return "Poem Title: " + title + ", Number of lines: " + lines;
    }

    public class Couplet extends Poem {


        public Couplet(String title) {
            super(title, 2);
        }

        @Override
        public String toString() {
            return "Couplet: " + getTitle() + ", Number of lines: " + getLines();
        }
    }

}
