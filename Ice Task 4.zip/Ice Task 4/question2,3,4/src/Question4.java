// DemoPoems.java
import java.util.Scanner;

public class DemoPoems {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        String title;
        int lines = 0;
        Poem poem = null;

        // Prompt user for type of Poem to create
        do {
            System.out.println("Select the type of poem to create:");
            System.out.println("1. Regular Poem");
            System.out.println("2. Couplet");
            System.out.println("3. Limerick");
            System.out.println("4. Haiku");
            System.out.print("Enter choice (1-4): ");
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
            } else {
                scanner.next(); // Clear invalid input
            }
        } while (choice < 1 || choice > 4);

        // Handle poem creation based on user's choice
        scanner.nextLine();  // Consume newline after the integer input

        System.out.print("Enter the title of the poem: ");
        title = scanner.nextLine();

        switch (choice) {
            case 1:
                // For regular poem, prompt for number of lines
                System.out.print("Enter the number of lines: ");
                if (scanner.hasNextInt()) {
                    lines = scanner.nextInt();
                } else {
                    System.out.println("Invalid input. Setting default number of lines to 1.");
                    lines = 1;
                }
                poem = new Poem(title, lines);
                break;
            case 2:
                poem = new Couplet(title);
                break;
            case 3:
                poem = new Limerick(title);
                break;
            case 4:
                poem = new Haiku(title);
                break;
        }

        // Display the created poem
        if (poem != null) {
            System.out.println(poem);
        }
    }
}
