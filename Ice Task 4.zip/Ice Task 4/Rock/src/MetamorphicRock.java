public class MetamorphicRock extends Rock {
    public MetamorphicRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        this.description = "Metamorphic rocks are formed when existing rocks are transformed by heat, pressure, and chemical reactions.";
    }
}
