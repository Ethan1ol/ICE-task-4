public class Rock {
    private int sampleNumber;
    String description;
    private double weight;

    public Rock(int sampleNumber, double weight) {
        this.sampleNumber = sampleNumber;
        this.description = "Unclassified";
        this.weight = weight;
    }

    public int getSampleNumber() {
        return sampleNumber;
    }

    public String getDescription() {
        return description;
    }

    public double getWeight() {
        return weight;
    }
}
