package Question2;

public class Candle {
    private String color;
    private int height;
    private int price;

    public void setColor(String colour){
        this.color = colour;
    }
    public void setHeight(int height){
        this.height = height;
    }

    public String getColor(){
        return color;
    }
    public int getHeight(){
        return height;
    }
    public int getPrice(){
        price = (getHeight()*2); //Calculates price
        return price;
    }
}

