import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the title of the Fiction book: ");
        String fictionTitle = scanner.nextLine();
        Fiction fictionBook = new Fiction(fictionTitle);

        System.out.print("Enter the title of the NonFiction book: ");
        String nonFictionTitle = scanner.nextLine();
        NonFiction nonFictionBook = new NonFiction(nonFictionTitle);

        displayBookDetails(fictionBook);
        displayBookDetails(nonFictionBook);
    }
    public static void displayBookDetails(Book book) {
        System.out.println("Title: " + book.getTitle());
        System.out.println("Price: $" + book.getPrice());
        System.out.println();
    }
}