package Question3;

import Question2.ScentedCandle;

import java.util.Scanner;

public class DemoTees {

    public static void main(String[] args){
    Scanner scanner = new Scanner(System.in);
    CustomTee myTees = new CustomTee();


    System.out.print("Order Number: ");
    String number = scanner.next();
    myTees.setNumber(Integer.parseInt(number));//number saved into set method

    System.out.print("Enter Colour: ");
    String colour = scanner.next();
    myTees.setColor(colour);//Color saved into set method

    System.out.print("Enter Size: ");
    String size = scanner.next();
    myTees.setSize(size);//Size saved into set method

    System.out.print("Enter Slogon: ");
    String slogon = scanner.next();
    myTees.setSlogon(slogon);//Slogan saved into set method

    System.out.println( "\n" + "Order Number " + myTees.getNumber() +"\n"+ "Colour: " + myTees.getColor() +"\n"+ "Size: " +myTees.getSize() + "\n" + "Slogon: " +myTees.getSlogon() +  "\n"+ "Price: $" +myTees.getPrice());

}}
