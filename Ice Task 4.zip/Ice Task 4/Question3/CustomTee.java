package Question3;

public class CustomTee extends TeeShirt {
private String slogon;

    public void setSlogon(String slogon){
        this.slogon = slogon;
    }
    public String getSlogon(){
        return slogon;
    }
}
