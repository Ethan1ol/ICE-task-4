package Question3;

public class TeeShirt {
    private String color;
    private String size;
    private int number;
    private double price;

    //setting method
    public void setColor(String colour){
        this.color = colour;
    }
    public void setSize(String size ){
        this.size = size;
    }
    public void setNumber(int number ){
        this.number = number;
    }

    //getting method
    public String getColor(){
        return color;
    }
    public String getSize(){
        return String.valueOf(size);
    }

    public int getNumber(){
        return number;
    }
    public double getPrice(){
        
        if(getSize().equalsIgnoreCase("XXL") || getSize().equalsIgnoreCase("XXXL")){
           price = 22.99; //price if XXL or XXXL
        }
        else {
          price = 19.99;//Other sizes
        }

        return price;
    }
}
