public class IncomingOutgingPhoneCall {
}
class IncomingPhoneCall extends PhoneCall {
    public IncomingPhoneCall(String phoneNumber) {
        super(phoneNumber);
        setPrice(0.02);
    }

    @Override
    public void displayCallInfo() {
        System.out.println("Phone Number: " + getPhoneNumber());
        System.out.println("Rate: 2 cents");
        System.out.println("Price: " + getPrice() + " cents");
    }
}

class OutgoingPhoneCall extends PhoneCall {
    private int timeInMinutes;

    public OutgoingPhoneCall(String phoneNumber, int timeInMinutes) {
        super(phoneNumber);
        this.timeInMinutes = timeInMinutes;
        setPrice(timeInMinutes * 0.04);
    }

    @Override
    public void displayCallInfo() {
        System.out.println("Phone Number: " + getPhoneNumber());
        System.out.println("Rate: 4 cents per minute");
        System.out.println("Time: " + timeInMinutes + " minutes");
        System.out.println("Price: " + getPrice() + " cents");
    }
}
