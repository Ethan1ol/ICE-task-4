import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PhoneCall phoneCall;
        while (true) {
            System.out.print("Enter the type of call (I for incoming, O for outgoing, or Q to quit): ");
            String type = scanner.next();
            if (type.equalsIgnoreCase("Q")) {
                break;
            }
            System.out.print("Enter the phone number: ");
            String phoneNumber = scanner.next();
            if (type.equalsIgnoreCase("I")) {
                phoneCall = new IncomingPhoneCall(phoneNumber);
            } else if (type.equalsIgnoreCase("O")) {
                System.out.print("Enter the time of the call in minutes: ");
                int timeInMinutes = scanner.nextInt();
                phoneCall = new OutgoingPhoneCall(phoneNumber, timeInMinutes);
            } else {
                System.out.println("Invalid input. Please try again.");
                continue;
            }
            phoneCall.displayCallInfo();
            System.out.println();
        }
    }
}