public class Blanket {
    private String size;
    private String color;
    private String material;
    public double price;

    public Blanket() {
        this.size = "Twin";
        this.color = "white";
        this.material = "cotton";
        this.price = 30.00;
    }

    public void setSize(String size) {
        switch (size) {
            case "Double":
                this.size = size;
                this.price += 10;
                break;
            case "Queen":
                this.size = size;
                this.price += 25;
                break;
            case "King":
                this.size = size;
                this.price += 40;
                break;
            default:
                this.size = "Twin";
                this.price = 30.00;
        }
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setMaterial(String material) {
        switch (material) {
            case "Wool":
                this.material = material;
                this.price += 20;
                break;
            case "Cashmere":
                this.material = material;
                this.price += 45;
                break;
            default:
                this.material = "cotton";
                this.price = 30.00;
        }
    }

    public String toString() {
        return "Blanket: " + size + ", " + color + ", " + material + ", $" + price;
    }
}