package Question4;

public class Poem {
    private String name;
    private int lines;

    public Poem(String name, int lines) {
        this.name = name;
        this.lines = lines;
    }

    public String getPoem() {
        return name;
    }

    public int getLines() {
        return lines;
    }
}
