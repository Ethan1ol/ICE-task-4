import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GeometricFigure[] figures = new GeometricFigure[5];

        for (int i = 0; i < 5; i++) {
            System.out.print("Enter the type of figure (S for Square or T for Triangle): ");
            String type = scanner.next();

            if (type.equalsIgnoreCase("S")) {
                System.out.print("Enter the side length: ");
                double sideLength = scanner.nextDouble();
                figures[i] = new Square(sideLength);
            } else if (type.equalsIgnoreCase("T")) {
                System.out.print("Enter the base: ");
                double base = scanner.nextDouble();
                System.out.print("Enter the height: ");
                double height = scanner.nextDouble();
                figures[i] = new Triangle(base, height);
            } else {
                System.out.println("Invalid input. Please try again.");
                i--;
                continue;
            }
        }

        for (GeometricFigure figure : figures) {
            System.out.println("Figure Type: " + figure.getFigureType());
            System.out.println("Height: " + figure.getHeight());
            System.out.println("Width: " + figure.getWidth());
            System.out.println("Area: " + ((figure instanceof Square) ? ((Square) figure).getArea() : ((Triangle) figure).getArea()));
            System.out.println();
        }
    }
}